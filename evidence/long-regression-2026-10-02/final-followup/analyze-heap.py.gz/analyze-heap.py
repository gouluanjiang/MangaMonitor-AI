import argparse,json,collections
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('snapshot',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
h=json.loads(a.snapshot.read_text());m=h['snapshot']['meta'];nf=m['node_fields'];ef=m['edge_fields'];n=h['nodes'];s=h['strings'];width=len(nf);types=m['node_types'][0]
by=collections.defaultdict(lambda:[0,0]);scope_strings=[]
for i in range(0,len(n),width):
 kind=types[n[i+nf.index('type')]];name=s[n[i+nf.index('name')]];size=n[i+nf.index('self_size')]
 label=name if len(name)<160 else f'<{kind}:name_length_{len(name)}>'
 by[(kind,label)][0]+=1;by[(kind,label)][1]+=size
 if kind=='string' and name.startswith('["search","author-tab-'):scope_strings.append({'nodeIndex':i//width,'bytes':size,'length':len(name)})
summary={'file':str(a.snapshot),'nodes':len(n)//width,'selfBytes':sum(v[1] for v in by.values()),'searchScopeStrings':{'count':len(scope_strings),'selfBytes':sum(v['bytes'] for v in scope_strings)},'topBySelfBytes':[{'type':k[0],'name':k[1],'count':v[0],'selfBytes':v[1]} for k,v in sorted(by.items(),key=lambda pair:pair[1][1],reverse=True)[:30]],'limits':'Shallow sizes and node counts only; not retained/dominator sizes, RSS or an automatic leak classification.'}
if a.output:a.output.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
