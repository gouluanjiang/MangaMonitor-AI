"""Read fixed-interval evidence; do not infer leakage from shallow heap or RSS."""
import argparse
import json
import math
import statistics
from pathlib import Path


def distribution(values):
    values = sorted(x for x in values if isinstance(x, (int, float)))
    if not values:
        return None
    return dict(samples=len(values), min=values[0], median=statistics.median(values),
                p95=values[max(0, math.ceil(len(values) * .95) - 1)], max=values[-1])


def keyed(row):
    return {(p['pid'], p['startTicks']): p for p in row['processes']}


parser = argparse.ArgumentParser()
parser.add_argument('directory', type=Path)
parser.add_argument('--cpu-quota-cores', type=float, default=4)
parser.add_argument('--clock-ticks', type=int, default=100)
args = parser.parse_args()
rows = [json.loads(line) for line in (args.directory/'pressure-metrics.ndjson').read_text().splitlines()]
assert len(rows) >= 2
assert all(b['elapsedMs'] > a['elapsedMs'] for a,b in zip(rows,rows[1:]))
samples = []
for index, row in enumerate(rows):
    ps = row['processes']
    datum = dict(elapsedMs=row['elapsedMs'], operations=row['operations'],
                 jsHeapMiB=row['metrics']['JSHeapUsedSize']/1048576,
                 summedRssMiB=sum(p['rssKb'] for p in ps)/1024,
                 summedAnonRssMiB=sum(p['rssAnonKb'] for p in ps)/1024,
                 runnerRssMiB=row['runnerMemory']['rss']/1048576,
                 runnerHeapUsedMiB=row['runnerMemory']['heapUsed']/1048576,
                 nodes=row['metrics']['Nodes'], listeners=row['metrics']['JSEventListeners'],
                 documents=row['metrics']['Documents'],
                 fdCount=sum(p['fds'] for p in ps) if all(p['fds'] is not None for p in ps) else None,
                 threadCount=sum(p['threads'] for p in ps), processCount=len(ps),
                 activeIPC=row['state']['active'], readerSessions=row['state']['readerSessions'])
    if all(p.get('proportionalMemory') and p['proportionalMemory'].get('PssKb') is not None for p in ps):
        datum['summedPssMiB'] = sum(p['proportionalMemory']['PssKb'] for p in ps)/1024
        datum['summedPrivateMiB'] = sum(p['proportionalMemory']['Private_CleanKb'] + p['proportionalMemory']['Private_DirtyKb'] for p in ps)/1024
    if index:
        prior = rows[index-1]
        seconds = (row['elapsedMs']-prior['elapsedMs'])/1000
        old = keyed(prior); new = keyed(row); common = old.keys() & new.keys()
        ticks = sum(new[key]['cpuTicks']-old[key]['cpuTicks'] for key in common)
        assert ticks >= 0
        datum['sampledProcessCpuQuotaPercent'] = ticks/args.clock_ticks/seconds/args.cpu_quota_cores*100
        datum['rendererMainThreadCpuOneCorePercent'] = (row['metrics']['TaskDuration']-prior['metrics']['TaskDuration'])/seconds*100
        datum['requestRatePerSecond'] = (row['state']['calls']-prior['state']['calls'])/seconds
        datum['operationRatePerMinute'] = (row['operations']-prior['operations'])/seconds*60
        datum['processIdentityChanges'] = len(old.keys() ^ new.keys())
    samples.append(datum)
fields=sorted(set().union(*(x.keys() for x in samples))-{'elapsedMs','operations'})
windows=[]
for start,end in [(0,20),(20,40),(40,60)]:
    selected=[x for x in samples if start*60000<=x['elapsedMs']<end*60000]
    windows.append({'fromMinute':start,'toMinute':end,'samples':len(selected),
                    **{name:distribution(x.get(name) for x in selected) for name in fields}})
start,end=rows[0],rows[-1]
last=end['state']; deltaCalls=last['calls']-start['state']['calls']; deltaErrors=last['failures']-start['state']['failures']
result={'directory':str(args.directory),'sampling':'nominal 60 seconds plus final sample; each window includes all four 5-minute background modes',
        'cpuQuotaCores':args.cpu_quota_cores,'clockTicks':args.clock_ticks,'firstSampleAt':start['at'],'lastSampleAt':end['at'],
        'windows':windows,'first':samples[0],'last':samples[-1],
        'sampledInterval':{'requests':deltaCalls,'boundaryFailures':deltaErrors,'errorRate':deltaErrors/deltaCalls if deltaCalls else None},
        'finalBoundary':last,
        'limits':['CPU of processes that are born and die entirely between samples is unmeasured.',
                  'Summed RSS double-counts shared pages; use measured PSS where available.',
                  'IPC in-flight counts and synthetic progress are not native worker-queue measurements.',
                  'Pressure timings are not attributed causal speedups: baseline overlapped native diagnostics and the tab-lifetime test; candidate overlaps the bounded reader-ready ABBA diagnostic.',
                  'Each process uses a finite image working set. Increasing retained objects requires ownership evidence before classification.']}
print(json.dumps(result,indent=2,ensure_ascii=False))
