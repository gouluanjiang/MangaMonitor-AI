"""Archive only allowlisted synthetic evidence after both pressure summaries pass."""
import json
import gzip
import hashlib
from pathlib import Path
from datetime import datetime, timezone
root=Path('/workspace/mangamonitor-soak')
repo=Path('/workspace/MangaMonitor-AI')
out=repo/'evidence/long-regression-2026-10-02/final-followup'
assert not out.exists(), 'preserve previous evidence; use a new archive destination'
for version in ['before','after']:
    s=json.loads((root/f'performance-{version}/summary.json').read_text())
    assert s['complete'] and not s['failed'] and s['pressureElapsedMs']>=3600000
tab=json.loads((root/'tab-lifetime-after-long/summary.json').read_text())
assert not tab['failed'] and tab['continuousMs']>=3600000
assert all(x['retainedScopes']==0 and x['retainedKeys']==0 for x in tab['checkpoints'])
files=[]
for name in ['performance-before','performance-after']:
    files.extend(sorted(f for f in (root/name).iterdir() if f.is_file() and f.suffix in ['.json','.ndjson','.heapsnapshot','.png']))
for name in ['summary.json','checkpoints.json']:
    files.append(root/'tab-lifetime-after-long'/name)
for name in ['reader-ready-1-before','reader-ready-qualification-02','reader-ready-final-1-before','reader-ready-final-2-after','reader-ready-final-3-after','reader-ready-final-4-before']:
    files.extend(sorted(f for f in (root/name).iterdir() if f.is_file() and f.suffix in ['.json','.ndjson','.png']))
preparation=[f'qualification-{i:02}' for i in range(1,7)]+['qualification-storage-01','qualification-storage-02']+[f'perf-qualification-{i:02}' for i in range(1,5)]
for name in preparation:
    directory=root/name
    assert directory.is_dir()
    files.extend(sorted(f for f in directory.iterdir() if f.is_file() and f.suffix in ['.json','.ndjson','.png','.log']))
names=['candidate-pressure-input.json','performance-input-consistency.json',
       'baseline-resource-table.json','candidate-ci-test-counts.json','remote-final-review.json',
       'performance-before-exit.json','performance-after-exit.json','tab-lifetime-after-long-exit.json',
       'performance-before-operation-audit.json','performance-after-operation-audit.json',
       'performance-before-analysis.json','performance-after-analysis.json',
       'performance-before-resources.json','performance-after-resources.json',
       'performance-before-heap-before.json','performance-before-heap-after.json',
       'performance-after-heap-before.json','performance-after-heap-after.json',
       'performance-before-heap-owners.json','performance-after-heap-owners.json',
       'performance-comparison.json','performance-matrix-comparison.csv',
       'analyze-pressure-resources.py','analyze-heap.py','inspect-heap-owners.py','compare-performance.py',
       'archive-final-followup.py','audit-final-durations.py','make-final-report.py','finalize-candidate-evidence.py','final-report-sections.md','final-handoff-section.md',
       'request-lifetime-probe.mjs','final-duration-audit.json','final-evidence-classification.json',
       'reader-ready-abba-manifest.json','reader-ready-comparison.json','reader-ready-probe-qualification.json',
       'reader-ready-probe-input.json','reader-ready-probe-input-v1.json','reader-ready-probe.mjs','reader-ready-probe-v1.mjs',
       'make-reader-ready-probe.py','run-reader-ready-abba.py',
       'performance-before-runner.log','performance-after-runner.log']
files.extend(root/name for name in names)
assert all(f.is_file() for f in files), [str(f) for f in files if not f.is_file()]
out.mkdir(parents=True)
entries=[]
for f in files:
    relative=f.relative_to(root);raw=f.read_bytes();packed=gzip.compress(raw,compresslevel=6,mtime=0)
    dest=out/(str(relative)+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
    entries.append({'file':str(dest.relative_to(out)),'uncompressedBytes':len(raw),
                    'compressedBytes':len(packed),'sha256':hashlib.sha256(raw).hexdigest(),
                    'compressedSha256':hashlib.sha256(packed).hexdigest()})
manifest={'capturedAt':datetime.now(timezone.utc).isoformat(),
          'applicationBaseline':'9afbb4b0470b3939b9f8f8e0848dcc1c3a8b3827',
          'applicationCandidate':'1cba4b81eaf439de9d00c47a42aeb11027b1e1fa',
          'candidateHarnessHead':'2cb4789251a28a88fa5ce7c045afe546b7181f70',
          'allScheduledSustainedPhasesComplete':True,'seed':20261002,
          'preparationEvidenceDirectories':preparation,
          'preparationCountsAsLongTest':False,
          'classification':'Functional and confirmed-fix assertions pass; whole-program resource leak attribution and local Windows acceptance remain limited.',
          'files':entries}
matrix=(root/'performance-matrix-comparison.csv').read_bytes()
(out/'performance-matrix-comparison.csv').write_bytes(matrix)
manifest['readableMatrix']={'file':'performance-matrix-comparison.csv','bytes':len(matrix),'sha256':hashlib.sha256(matrix).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'archive':str(out),'files':len(entries),'bytes':sum(x['compressedBytes'] for x in entries)}))
