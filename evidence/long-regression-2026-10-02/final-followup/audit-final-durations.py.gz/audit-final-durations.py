import json
from pathlib import Path
from datetime import datetime,timezone,timedelta
root=Path('/workspace/mangamonitor-soak')
def parse(text):return datetime.fromisoformat(text.replace('Z','+00:00'))
def ms(text):return parse(text).timestamp()*1000
segments=[]
b=json.loads((root/'baseline-ui/summary.json').read_text())
assert b['complete'] and b['failed']==0
segments.append({'name':'baseline-ui','started':b['started'],'measuredEnd':b['ended'],'continuousMs':b['continuousMs'],'operations':b['operations'],'unit':'multi-action scenario operations','sameProcess':True,'role':'primary-ui'})
s=json.loads((root/'baseline-storage/summary.json').read_text());assert s['complete']
segments.append({'name':'baseline-storage','started':datetime.fromtimestamp(s['startedUnixMs']/1000,timezone.utc).isoformat(),'measuredEnd':datetime.fromtimestamp(s['endedUnixMs']/1000,timezone.utc).isoformat(),'continuousMs':s['continuousMs'],'operations':s['operations'],'unit':'native store scenario operations','sameProcess':'same parent; killed synthetic writer children are part of fault scenarios','role':'parallel-native'})
for version in ['before','after']:
 s=json.loads((root/f'performance-{version}/summary.json').read_text());assert s['complete'] and not s['failed']
 end=parse(s['pressureStarted'])+timedelta(milliseconds=s['pressureElapsedMs'])
 segments.append({'name':f'performance-{version}-pressure','started':s['pressureStarted'],'measuredEnd':end.isoformat(),'measurementEndIsDerived':True,'processExit':s['ended'],'continuousMs':s['pressureElapsedMs'],'operations':s['pressureOperations'],'matrixOperationsSeparate':s['completedTrials']*10,'matrixTrialsSeparate':s['completedTrials'],'unit':'multi-action scenario operations','sameProcess':True,'role':'primary-ui','excluded':'image preparation, all matrix browser processes, pre/post GC and heap snapshots'})
s=json.loads((root/'tab-lifetime-after-long/summary.json').read_text());assert not s['failed'] and s['continuousMs']>=3600000
segments.append({'name':'tab-lifetime-after-long','started':s['started'],'measuredEnd':s['ended'],'continuousMs':s['continuousMs'],'operations':s['closed'],'unit':'author tabs closed after exercising source view variants','sameProcess':True,'role':'parallel-lifetime-diagnostic','note':'GC every ten closures; not natural no-GC memory behavior'})
intervals=sorted((ms(s['started']),ms(s['started'])+s['continuousMs']) for s in segments)
merged=[]
for start,end in intervals:
 if merged and start<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],end)
 else:merged.append([start,end])
primary=[s for s in segments if s['role']=='primary-ui']
result={'segments':segments,'primaryUiAccumulatedMs':sum(s['continuousMs'] for s in primary),
        'primaryUiContinuousMaximumMs':max(s['continuousMs'] for s in primary),
        'primaryUiScenarioOperations':sum(s['operations'] for s in primary),
        'allParallelStreamsUnionMs':sum(end-start for start,end in merged),
        'limits':['No sum of overlapping browser/native/lifetime process durations is called continuous or accumulated user testing.',
                  'The headline accumulated UI duration comprises three separate processes: four-hour baseline, one-hour baseline pressure and one-hour candidate pressure.',
                  'Matrix trials and targeted diagnostics are counted separately; preparation is excluded.',
                  'Performance pressure end times are derived from wall start plus monotonic measured elapsed time; process exit includes excluded final diagnostics.']}
(root/'final-duration-audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result,indent=2,ensure_ascii=False))
