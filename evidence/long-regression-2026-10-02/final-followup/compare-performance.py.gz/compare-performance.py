"""Produce descriptive paired matrix tables from identical fixed-seed runs."""
import csv
import json
from pathlib import Path
import argparse
from datetime import datetime, timezone, timedelta

p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();root=a.root
before=json.loads((root/'performance-before-analysis.json').read_text())
after=json.loads((root/'performance-after-analysis.json').read_text())
assert before['summary']['complete'] and after['summary']['complete']
keys=['size','background','scenario','phase']
def index(data):return {tuple(row[k] for k in keys):row for row in data['matrix']}
bi=index(before);ai=index(after);assert bi.keys()==ai.keys()
rows=[]
for key in sorted(bi):
    row=dict(zip(keys,key))
    for metric in ['firstMs','completeMs','ipcCalls']:
        for label,data in [('before',bi[key]),('after',ai[key])]:
            value=data[metric]
            if value:
                for field in ['samples','median','p95','min','max']:row[f'{metric}_{label}_{field}']=value[field]
    rows.append(row)
fields=list(dict.fromkeys(k for row in rows for k in row))
with (root/'performance-matrix-comparison.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
summary={'createdAt':datetime.now(timezone.utc).isoformat(),'matrixRows':len(rows),'comparisons':rows,
         'limits':['Five trials per exact condition. P95 is the maximum, not an estimated production tail.',
                   'Both versions use identical synthetic delay and images; changes cannot represent source-network speedup.',
                   'Cold means a new browser/app cache; host OS caches are not flushed.',
                   'The isolated ABBA source-render and native observation probes establish the targeted speedups; general UI matrix is regression/coverage evidence.'],
         'pressure':{}}
for label,data in [('before',before),('after',after)]:
    s=data['summary'];end=datetime.fromisoformat(s['pressureStarted'].replace('Z','+00:00'))+timedelta(milliseconds=s['pressureElapsedMs'])
    summary['pressure'][label]={k:s[k] for k in ['pressureStarted','pressureElapsedMs','pressureOperations','ended','operations','completedTrials','failed','stopped']}
    summary['pressure'][label]['measuredEndDerivedUtc']=end.isoformat()
(root/'performance-comparison.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'matrixRows':len(rows),'pressure':summary['pressure']},indent=2))
