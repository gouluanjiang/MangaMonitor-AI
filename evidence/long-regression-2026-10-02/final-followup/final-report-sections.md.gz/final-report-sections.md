## Confirmed issues and minimal changes

The original four-hour baseline finished before any application change. Its
functional assertions passed; resource trends and the user's static leads then
guided three repeatable diagnostics. A passing scenario loop did not conceal
these independently reproduced defects. No application changes were made for
the remaining unproven leads.

| Confirmed problem | Failure evidence | Minimal change | Validation |
| --- | --- | --- | --- |
| Closed author tabs retain complete position-key snapshots | Production diagnostic: 40 closed tabs retain 40 scopes / 7,200 keys after GC; retained keys rise at every ten-tab checkpoint | Track scopes owned by an ephemeral author tab; delete them after its final layout-unmount save. Hidden/open tabs and ordinary page positions retain their previous behavior | Same 40-tab reproduction retains zero; logic test protects neighboring scopes; CI tests all three source variants; sustained result below |
| Unrelated source selection renders repeatedly filter/sort an unchanged catalog | 20 enter-selection/cancel pairs on 2,000 works invoke the title comparator 760,673 times; the zero-redundant-comparison assertion fails on the baseline | Memoize derived lists against actual data/query/sort/inventory inputs, including the existing explicit-content-evidence revision | Identical production probe performs zero comparisons and preserves displayed order; full label/filter and browser suites pass |
| Observation commits repeatedly parse unchanged local bytes | Release 20,000-record probe exposes about 99 ms per detail commit; cache-contract test fails with `unchanged observed-works.json was parsed again` | Add one observation-document slot to the existing exact-byte validated cache | Same-revision changed bytes invalidate; corrupt/future data is preserved and rejected; stale CAS rejects; four ABBA runs end with byte-identical observation documents |

The third change retains the existing file read, file identity checks, schema
and validation rules, CAS, atomic writes and limits (64 MiB serialized document,
100,000 observed works, 20,000 recent-history items). It caches a single current
raw document and parsed snapshot per store cache, not an entry per request or
author. It does **not** make observations asynchronous or weaken freshness.
The original whole-file write cost remains.

### Comparable targeted performance

All times below are milliseconds. Both targeted comparisons use ABBA order,
the same synthetic input and the same diagnostic code. Source-render samples
use the same Chromium build; observation samples use Rust 1.98.1 release builds
in distinct target directories. The native final documents are byte-identical.

| Probe | Samples per version | Before median / p95 | After median / p95 |
| --- | ---: | ---: | ---: |
| Source selection pair, 2,000 works | 40 | 394.68 / 441.38 | 330.02 / 378.46 |
| Observation fresh read, 20,000 records | 20 | 35.06 / 48.10 | 36.14 / 52.99 |
| Observation retained handle, changed file | 20 | 34.96 / 41.44 | 38.74 / 48.49 |
| Observation warm unchanged-file read | 20 | 34.30 / 44.59 | 4.44 / 8.50 |
| Observation merge of 30-record page | 20 | 99.49 / 132.61 | 70.30 / 88.48 |
| Observation merge of one detail | 20 | 99.17 / 117.49 | 66.38 / 93.23 |
| Observation 32-record warm read | 20 | 0.090 / 0.127 | 0.039 / 0.043 |
| Observation 32-record page commit | 20 | 1.459 / 3.997 | 0.950 / 2.573 |

The specific improvements are about 16.4% for the selection interaction, 29.3%
for the large page commit and 33.1% for the large detail commit. Cold reads did
not improve. These are local computation/commit measurements, not real-network
speedups. The source comparator call count falls from 1,521,346 to zero across
the two measured baseline/after runs per version.

Caching has a measured memory cost: the whole native diagnostic's peak RSS rose
from 111,512 to 178,904 KiB (about 109 to 175 MiB); user CPU fell from 3.387 to
2.572 seconds and system CPU rose from 0.139 to 0.220 seconds. These are fresh
process peak/CPU measurements, not isolated allocation sizes or evidence of a
long-term leak. No lower whole-program memory claim is made.

### Reader timing outlier classification

The original five-round matrix showed two 2,000-entry warm-reader median shifts:
418.54→663.96 ms with both background modes, and 439.50→642.89 ms with download
progress. The complete-time assertion uses Playwright polling; raw samples
cluster about 105 or 360 ms after the reader-shell observation.

A separate ABBA diagnostic kept every original assertion and added passive
animation-frame timestamps for a decoded visible image. Ten warm samples per
condition/version measured **435.95→436.00 ms** (download) and
**433.95→433.70 ms** (both). The original poll observation lag is about
236–246 ms at the median. The apparent 200–250 ms readiness regression did not
reproduce with that observer; no application change was made for this signal.
The original matrix remains archived. A first diagnostic-qualification failure
(reading the passive observer before its next frame) and its script are also
preserved; qualification and final ABBA results are separate. Frame precision,
small sample counts and concurrent pressure limit the diagnostic; it does not
prove invariant reader latency on all platforms.

### Native loading and recovery

Direct release diagnostics generated 24 and 2,000 ZIP entries, each with two
chapters and three generated JPEG pages, and passed 172 checks. Catalog and
archive bytes stayed unchanged. Small/large medians: warm list 0.042/0.862 ms;
cover load 14.99/16.64 ms; reader open plus first page 0.294/1.036 ms; page read
0.116/0.310 ms. Initial generated-library scans took 4.78/165.63 ms (one sample
at each size). The largest measured page read was 0.799 ms. This does not
establish per-page ZIP indexing as this batch's bottleneck; no reader-index
rewrite was made. These direct Linux timings exclude Windows IPC/WebView.

Five additional Linux ENOSPC tests passed locally and in exact-candidate CI.
They inject write failures only under fresh marked synthetic roots: ZIP and
directory zero/partial writes, and partial preference atomic writes. Five
native fault events plus the injector scope self-check produce six trace entries.
Previous valid data, library/download ledgers and an outside-injection sentinel
are preserved. Locks release; explicit retry after clearing
the injected fault succeeds with a verified receipt. No actual disk filling or
system/security configuration change is used. The ordinary suite deliberately
ignores these armed tests; the separate guarded CI step explicitly executes all
five and fails if any are omitted.

Existing required native suites also cover cancellation/drain, exact-prefix
partial-file resume, destination/name collisions, revision-bound queue changes,
corrupt/future documents, in-memory legacy migration until an explicit write,
and preservation of old state after partial source failures. The long storage
run exercises real store APIs with parallel writers and killed temporary writer
children. Corruption recovery restores the fixture's saved known-good backup;
this is **not** a claim that the product automatically repairs arbitrary damage.

### Static leads resolved, not established, and deferred

| Lead | Disposition in this batch |
| --- | --- |
| Closed author-tab browse positions | Confirmed and fixed; other accounts' retained maps are not inferred from this fix |
| SourceWorkbench repeated filtering/sorting | Confirmed and fixed only for measured unchanged-input renders |
| Observation duplicate local parse/commit cost | Confirmed and fixed only through the bounded existing-cache mechanism |
| Reader stale in-flight pages | Actual cache probe: 1,000 desired-window changes, maximum two active promises, no stale publication, zero active/entries after close. Old started requests still occupy slots; the controlled jump takes 147.83 ms with 80 ms promises. Not a native network benchmark; finer cancellation remains deferred |
| Detail per-call GET / request coalescing | No long-run backlog or cross-author overwrite reproduced at the synthetic boundary; native per-detail cancellation/coalescing remains unverified and unchanged |
| Per-page ZIP indexing | Generated native probe did not establish a meaningful bottleneck at the tested sizes; defer |
| Invalid-account savedViews / recent readers/views | Static retention paths remain; no account-churn RSS attribution or fix claimed |
| useBrowsingMarkers on progress; collection used_at full writes; preference background decode/write | Not independently established as this run's dominant cost; unchanged |
| Account lock during ranking; synchronous Windows Vault wait; joined account restoration; online metadata non-LRU eviction | Need applicable native/account evidence; unchanged |
| Download inventory duplicate verification | 24,683 mocked inventory reads observed in the baseline; this measures boundary traffic, not native full-file verification cost. Singleflight deferred |
| Diagnostic missing-code whitelist; inactive old cloud monitoring | Deferred outside the measured fixes; not declared harmless or resolved |
| Whole-browser RSS growth | Retained tab data is proven; DevTools-owned resource records are also present. Total RSS/PSS attribution remains incomplete; no blanket no-leak acceptance |

Per-launch fixed browsing badges, special-follow unread state, successful
manual-scan additions, source + work-ID identity, history cap 100 and current
explicit-tag filtering remain distinct and unchanged. Unknown tags remain
visible; there is no title/author/cover inference or extra filtering detail
request. Recycle confirmation and fail-closed Windows recycle semantics remain.

## Exact candidate, CI and Windows acceptance boundary

Application candidate: `1cba4b81eaf439de9d00c47a42aeb11027b1e1fa` on draft
[PR #26](https://github.com/gouluanjiang/MangaMonitor-AI/pull/26), stacked on
`codex/library-browse-followups`. Later evidence/document commits do not change
this application or its candidate artifact. Nothing was merged, released or
installed into the user's profile.

| Required check on that exact SHA | Result |
| --- | --- |
| [Baseline / Linux + Windows executor](https://github.com/gouluanjiang/MangaMonitor-AI/actions/runs/36986184293) | Passed. Linux log: 1,094 Rust test executions, plus five explicitly armed ENOSPC tests; Windows executor: 63. Counts are executions, not distinct cross-job tests |
| [Frontend](https://github.com/gouluanjiang/MangaMonitor-AI/actions/runs/36986184319) | Passed: 356 logic, 268 browser cases, production build/format, added tab-lifetime and unchanged-catalog render probes |
| [Windows desktop](https://github.com/gouluanjiang/MangaMonitor-AI/actions/runs/36986184306) | Passed: 659 Rust test executions across job stages (including 57 native IPC), Clippy/format, 23 installer/license guards, native WebView/restart and isolated silent installer lifecycle |

The Linux cover profiling test remains outside the ordinary suite. Windows
credential-roundtrip tests use only random disposable CI slots and run in their
explicit step; no user credentials were accessed. No ignored armed fault test
is represented as having passed the ordinary suite.

Verified [Windows candidate artifact](https://github.com/gouluanjiang/MangaMonitor-AI/actions/runs/36986184306/artifacts/11218078107),
name `mangamonitor-windows-candidate-1cba4b81eaf439de9d00c47a42aeb11027b1e1fa`:

| Item | SHA-256 |
| --- | --- |
| Artifact ZIP | `0990b87b39892c48cd2fcdf59f767ab3bd29323bb2288740adacea3d5d990a0b` |
| `MangaMonitor Dev_1.0.2-rc.3_x64-setup.exe` | `08c1ebf132672781719618f097bcd1c68deee9c3d5b123eedc7e211f531a3437` |
| Packaged `mangamonitor-workbench-preview.exe` | `22eb3392db01efa03a51a6331699948ec135ae9bce127e370a0d306749ca5107` |

A diagnostic build-consistency incident was caught before final measurements:
a detached baseline worktree had reused a Cargo target directory, and a candidate
build reported `Fresh` while retaining the baseline example hash. That artifact
was rejected. Final candidate profiling used a separate target, distinct verified
binary hashes and the same benchmark source; it is the final ABBA evidence above.
No application behavior was inferred from the rejected build.

All eight candidate manifest files match their byte counts and hashes; source
and checkout revisions match. Package, Rust/Tauri config, manifest and runtime
version all report `1.0.2-rc.3`; `production_enabled=false` remains. The NSIS
`UNK`→`NSS` marker is accounted for at offset 19,887,682; CI verifies the exact
permitted binary difference. The candidate is unsigned Dev RC, not a release.
All 20 CI frontend files match the cloud-local candidate distribution byte for
byte. Candidate retention is 14 days; supporting UI/native evidence is seven
days. The final evidence archive preserves the manifests, hashes and CI logs.

Windows CI used WebView2 `153.0.4234.48` already present on the runner. It tested
restarting the exact candidate, independent reader windows, pin/main-hide/restore,
OS-owned HWND close messages with the frontend close handshake, generated
temporary-ZIP recycle with recycle-bin identity proof, and isolated silent
install/reinstall/uninstall with data/shortcut/registration checks. It does not
replace the user's final local acceptance.

Local Windows items still pending:

- Physical window close-button interaction and natural reader use with real
  user media; CI lifecycle evidence explicitly records `mediaRead=false` and
  `physicalCloseButtonTested=false`.
- Explorer's visibly selected file/location, interactive installer pages,
  historical `0.3.4` upgrade and the user's actual shortcut/environment.
- Windows volume-level ENOSPC behavior; syscall fault injection here is Linux only.
- Multi-hour native WebView/media/decode/download/scan resource behavior. The
  cloud browser backgrounds model IPC progress, not native executor CPU/I/O.
- User acceptance of real future special-follow new-work notifications and
  natural per-launch new badges. Synthetic success does not grant acceptance.

Expected candidate behavior for local acceptance: closing an author tab releases
its private saved positions while switching open tabs preserves their anchors;
selection toggles leave source order and tag filtering intact; observations
return the same fresh complete data with lower warm local-commit cost; corrupt
or conflicting files still fail visibly without reset/overwrite. Local approval
to install or touch the real profile remains separate from this task.
