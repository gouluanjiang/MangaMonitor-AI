"""Finalize only the completed, independently observed zero-exit candidate run."""
from pathlib import Path
import subprocess,json,datetime,collections
r=Path('/workspace/mangamonitor-soak');repo=Path('/workspace/MangaMonitor-AI')
summary=json.loads((r/'performance-after/summary.json').read_text())
exit_proof=json.loads((r/'performance-after-exit.json').read_text())
assert summary['complete'] and not summary['failed'] and not summary['stopped']
assert summary['pressureElapsedMs']>=3600000 and exit_proof['exitCode']==0

def run(script,args,output):
    with (r/output).open('w') as f:
        subprocess.run(['python3',str(script),*map(str,args)],cwd=repo,stdout=f,check=True)

rows=[json.loads(line) for line in (r/'performance-after/operations.ndjson').read_text().splitlines()]
begins=[x for x in rows if x['event']=='begin'];passes=[x for x in rows if x['event']=='pass']
assert len(begins)==len(passes)==summary['pressureOperations']
assert [x['operation'] for x in passes]==list(range(1,len(passes)+1))
assert all(b['operation']==p['operation'] and b['choice']==p['choice'] for b,p in zip(begins,passes))
coverage={name:sum(x['choice'] in choices for x in passes) for name,choices in [('author',[0]),('reader',[1,2]),('detail',[3]),('library',[4]),('recent',[5])]}
(r/'performance-after-operation-audit.json').write_text(json.dumps({'complete':True,'beginCount':len(begins),'passCount':len(passes),'contiguousOperations':True,'matchingChoices':True,'coverage':coverage},indent=2)+'\n')
for version in ['before','after']:
    run(repo/'scripts/summarize-performance.py',[r/f'performance-{version}'],f'performance-{version}-analysis.json')
    run(r/'analyze-pressure-resources.py',[r/f'performance-{version}'],f'performance-{version}-resources.json')
for position in ['before','after']:
    run(r/'analyze-heap.py',[r/f'performance-after/pressure-{position}.heapsnapshot'],f'performance-after-heap-{position}.json')
run(r/'inspect-heap-owners.py',[r/'performance-after/pressure-after.heapsnapshot'], 'performance-after-heap-owners.json')
run(r/'compare-performance.py',[r], 'performance-comparison-output.json')
run(r/'audit-final-durations.py',[], 'final-duration-audit-output.json')

classification={
 'finishedAt':summary['ended'],'applicationBaseline':'9afbb4b0470b3939b9f8f8e0848dcc1c3a8b3827',
 'applicationCandidate':'1cba4b81eaf439de9d00c47a42aeb11027b1e1fa',
 'candidateHarness':'2cb4789251a28a88fa5ce7c045afe546b7181f70',
 'allPlannedSustainedPhasesComplete':True,'functionalAssertionsPassed':True,
 'wholeProgramNoLeakAcceptance':False,'localWindowsUserAcceptance':False,
 'confirmedFixed':[
  {'issue':'Closed author-tab position snapshots retained globally','commit':'1a1b1a53aed5d028b258ff1826adefa68d69b96d','before':'40 scopes / 7200 keys after closing 40 tabs','after':'0 retained closed positions across 2054 tab closures / 206 checkpoints; three source variants per tab'},
  {'issue':'Unrelated 2000-work source renders repeat title sorting','commit':'25e3c106bc8df58563f4ce3be97298267ed72d9b','before':'760673 title comparisons per 20 unchanged selection pairs','after':'0; paired ABBA preserves displayed order'},
  {'issue':'Repeated parse of unchanged observation bytes during local commits','commit':'1cba4b81eaf439de9d00c47a42aeb11027b1e1fa','before':'cache-contract assertion fails; large detail commit median 99.17ms','after':'same integrity/CAS/future/corruption tests pass; detail median 66.38ms; native peak RSS tradeoff 111512 -> 178904 KiB'}],
 'notProductEvidence':[
  'Initial fixture locator, cover-retry and setup assumptions; qualification outputs remain separate from long test.',
  'Wrong synthetic schema_version field was correctly rejected; corrected to the actual schemaVersion format.',
  'Shared Cargo target returned a baseline binary for candidate Fresh build: rejected and rebuilt in separate target before final ABBA.',
  'Warm-reader matrix 200-250ms shift not reproduced in decoded-visible-image ABBA; original poll observation interval measured separately.',
  'First passive observer qualification sampled before next frame; original product assertion passed; failure/script retained.',
  'Original external PSS observer denied; subsequent in-process supplemental observer records available PSS without permission changes.',
  'Cloud browser CDN restriction: installed Chromium 151 used and recorded; not the pinned CI browser.'],
 'requestLifecycle':'Controlled actual-cache probe is bounded/drained and avoids stale publication, but started old requests retain slots; no native finer-grained cancellation/coalescing claim.',
 'resourceBoundary':'Baseline browser RSS/PSS growth is not wholly attributed. Application tab retention and InspectorNetworkAgent ownership are separately evidenced. Summed RSS is not unique memory; concurrent browsers affect PSS sharing.',
 'deferred':['Invalid-account view/reader map retention','Marker work on progress-only view changes','Collection used_at writes and preference background decode/write','Ranking account lock and Windows Vault thread wait','Joined account readiness','Online metadata eviction policy','Download inventory singleflight/native verification cost','Missing diagnostic-code whitelist entries','Inactive old cloud monitoring debt'],
 'nativeZipIndexing':'Native generated ZIP probe did not establish the per-page reindex as the measured bottleneck; unchanged.',
 'windowsBoundary':['Physical close-button interaction','User media and multi-hour native WebView resource behavior','Explorer visibly selected location','Interactive installer/historical 0.3.4 upgrade','Windows volume-level ENOSPC behavior','Real future special-follow notifications and natural new badges remain user acceptance'],
 'noRealMangaProfilesMediaCredentialsOrSourceTraffic':True,'noMergeReleaseUserInstallOrSecurityChanges':True,'isolatedCiInstallPerformed':True,
}
(r/'final-evidence-classification.json').write_text(json.dumps(classification,indent=2,ensure_ascii=False)+'\n')
run(r/'archive-final-followup.py',[], 'final-archive-output.json')
run(r/'make-final-report.py',[], 'final-report-output.json')
state=json.loads((r/'coordinator-state.json').read_text());state['updated']=datetime.datetime.now(datetime.timezone.utc).isoformat();state['performanceAfter'].update(complete=True,exitCode=0,ended=summary['ended'],pressureElapsedMs=summary['pressureElapsedMs'],pressureOperations=summary['pressureOperations']);state['remaining']=['Review final rendered evidence and hashes','Commit/push documentation and evidence; update same draft PR #26','Observe required automatically triggered documentation-head CI'];state['next']=state['remaining'];(r/'coordinator-state.json').write_text(json.dumps(state,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'summary':summary,'coverage':coverage,'archive':json.loads((r/'final-archive-output.json').read_text())},indent=2))
