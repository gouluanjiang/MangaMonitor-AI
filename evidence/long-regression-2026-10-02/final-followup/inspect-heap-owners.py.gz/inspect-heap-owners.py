"""Bounded reverse-edge inspection for observed synthetic browser objects."""
import json
import argparse
from pathlib import Path
from collections import defaultdict

p=argparse.ArgumentParser();p.add_argument('snapshot',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
h=json.loads(a.snapshot.read_text());m=h['snapshot']['meta'];nf=m['node_fields'];ef=m['edge_fields'];nodes=h['nodes'];edges=h['edges'];strings=h['strings'];nw=len(nf);ew=len(ef)
ni={v:i for i,v in enumerate(nf)};ei={v:i for i,v in enumerate(ef)};nt=m['node_types'][0];et=m['edge_types'][0]
def node(index):
 k=index*nw;name=strings[nodes[k+ni['name']]]
 return {'index':index,'type':nt[nodes[k+ni['type']]],'name':name[:180],'selfBytes':nodes[k+ni['self_size']]}
targets={}
for i in range(len(nodes)//nw):
 d=node(i)
 if d['name']=='blink::NetworkResourcesData::ResourceData' and 'resource' not in targets:targets['resource']=i
 if d['type']=='string' and d['name'].startswith('["search","author-tab-') and 'authorScope' not in targets:targets['authorScope']=i
current=set(targets.values());seen=set();layers=[]
for depth in range(6):
 reverse=defaultdict(list);offset=0
 for source in range(len(nodes)//nw):
  count=nodes[source*nw+ni['edge_count']]
  for k in range(offset,offset+count*ew,ew):
   dest=edges[k+ei['to_node']]//nw
   if dest in current:
    kind=et[edges[k+ei['type']]];label=edges[k+ei['name_or_index']]
    if kind not in ['element','hidden']:label=strings[label]
    if len(reverse[dest])<12:reverse[dest].append({'edgeType':kind,'edgeName':str(label)[:160],'parent':node(source)})
  offset+=count*ew
 layer=[{'target':node(dest),'parents':reverse.get(dest,[])} for dest in sorted(current)]
 layers.append({'depth':depth,'entries':layer});seen|=current
 current={parent['parent']['index'] for entry in layer for parent in entry['parents'] if parent['edgeType']!='weak'}-seen
 if len(current)>35:current=set(sorted(current)[:35])
 if not current:break
out={'snapshot':str(a.snapshot),'selectedTargets':{key:node(i) for key,i in targets.items()},'layers':layers,
     'limits':'Sampled reverse edges (max 12 per node, 35 nodes per level, six levels), not exhaustive dominator/retained-size analysis or proof of RSS attribution. Inspector-owned objects are distinct from application-owned caches.'}
if a.output:a.output.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out,indent=2,ensure_ascii=False))
