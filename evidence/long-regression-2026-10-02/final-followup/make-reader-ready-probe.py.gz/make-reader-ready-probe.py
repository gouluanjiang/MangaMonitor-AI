"""Add passive rAF timestamps; preserve the original image-ready assertions."""
from pathlib import Path
import hashlib
import json
root=Path('/workspace/MangaMonitor-AI/apps/local-workbench')
out=Path('/workspace/mangamonitor-soak')
source=root/'tests/soak/performance.mjs'
text=source.read_text()
def replace_once(old,new):
    global text
    assert text.count(old)==1, (old,text.count(old))
    text=text.replace(old,new)
replace_once('from "@playwright/test";', 'from "file:///workspace/MangaMonitor-AI/apps/local-workbench/node_modules/.pnpm/@playwright+test@1.63.0/node_modules/@playwright/test/index.mjs";')
replace_once('from "./fixture.mjs";', 'from "file:///workspace/MangaMonitor-AI/apps/local-workbench/tests/soak/fixture.mjs";')
replace_once('for (const size of [24, 2000])', 'for (const size of [2000])')
replace_once('for (const background of ["idle", "scan", "download", "both"])', 'for (const background of ["download", "both"])')
replace_once('  const start = performance.now();\n  const firstMs = await action(start);', '''  if (scenario === "reader") {
    await session.page.evaluate(() => {
      const probe = window.readerReadyDiagnostic = {start: performance.now(), firstFrameMs: null, imageFrameMs: null, frames: 0};
      const visible = (element) => {
        const r = element.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < innerHeight;
      };
      const frame = () => {
        probe.frames++;
        const elapsed = performance.now() - probe.start;
        const shell = document.querySelector('[data-testid="comic-reader"]');
        if (probe.firstFrameMs === null && shell && visible(shell)) probe.firstFrameMs = elapsed;
        const ready = [...document.querySelectorAll('[data-reader-page] img')]
          .some((img) => visible(img) && img.complete && img.naturalWidth > 0);
        if (ready) { probe.imageFrameMs = elapsed; return; }
        if (elapsed < 20000) requestAnimationFrame(frame);
      };
      requestAnimationFrame(frame);
    });
  }
  const start = performance.now();
  const firstMs = await action(start);''')
replace_once('  latencyRows++;\n  emit("latency.ndjson", row);\n  return row;', '''  if (scenario === "reader") {
    row.readerReadyDiagnostic = await session.page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => resolve(window.readerReadyDiagnostic))));
    assert(row.readerReadyDiagnostic.imageFrameMs !== null, "passive readiness observer did not see a decoded visible image: " + JSON.stringify(row.readerReadyDiagnostic));
  }
  latencyRows++;
  emit("latency.ndjson", row);
  return row;''')
dest=out/'reader-ready-probe.mjs';dest.write_text(text)
manifest={'originalScriptSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
          'generatedScriptSha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
          'source':str(source),'generated':str(dest),'size':2000,'backgrounds':['download','both'],
          'changes':['Passive rAF first-frame and decoded-visible-image timestamps, about one frame precision.',
                     'Subset of original matrix conditions, same fixed seed, five rounds, no pressure stage.',
                     'Original Playwright visibility/image readiness assertions and polling are unchanged.'],
          'limits':['This diagnosis runs beside the ongoing mixed pressure; ABBA handles drift but does not make timings production network measurements.',
                    'rAF probe includes about one command round trip relative to host measurement start. Probe collection waits one animation frame after the original poll completes; original host completeMs is captured before that wait.']}
(out/'reader-ready-probe-input.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
