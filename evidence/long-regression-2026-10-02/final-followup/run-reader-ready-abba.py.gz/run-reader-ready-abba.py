import subprocess,json,datetime,hashlib
from pathlib import Path
r=Path('/workspace/mangamonitor-soak');cwd=Path('/workspace/MangaMonitor-AI/apps/local-workbench')
script=r/'reader-ready-probe.mjs'; digest=hashlib.sha256(script.read_bytes()).hexdigest()
assert json.loads((r/'reader-ready-qualification-02/summary.json').read_text())['complete']
order=['before','after','after','before'];runs=[]
for i,version in enumerate(order,1):
    out=r/f'reader-ready-final-{i}-{version}'; assert not out.exists()
    command=['node','--expose-gc',str(script),'--rounds=5','--pressure-minutes=0','--seed=20261002',
             '--dist='+str(r/('baseline-dist' if version=='before' else 'candidate-dist')),
             '--chromium=/usr/bin/chromium','--output='+str(out)]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (r/f'{out.name}.log').open('w') as log:
        result=subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    summary=json.loads((out/'summary.json').read_text())
    record={'order':i,'version':version,'started':started,'ended':summary['ended'],
            'directory':out.name,'exitCode':result.returncode,'complete':summary['complete'],
            'scriptSha256':digest,'trials':summary['completedTrials']}
    runs.append(record)
    (r/'reader-ready-abba-manifest.json').write_text(json.dumps({'order':'ABBA','runs':runs,'complete':len(runs)==4,'parentTask':'Current long regression; classify two observed matrix outliers only.'},indent=2)+'\n')
    print(json.dumps(record),flush=True)
    assert result.returncode==0 and summary['complete']
    assert hashlib.sha256(script.read_bytes()).hexdigest()==digest
